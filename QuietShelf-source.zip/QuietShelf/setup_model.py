"""One-time public model download. Runtime never downloads or executes remote code."""
import hashlib,json,urllib.request
from pathlib import Path

ROOT=Path(__file__).resolve().parent
REPO='sentence-transformers/all-MiniLM-L6-v2'
def main():
    target=ROOT/'models'; target.mkdir(exist_ok=True)
    lock=json.loads((ROOT/'model-lock.json').read_text('utf8'))
    revision=lock['revision']
    manifest={'repository':REPO,'revision':revision,'license':'Apache-2.0','files':{}}
    for remote,local in [('onnx/model.onnx','model.onnx'),('tokenizer.json','tokenizer.json'),('README.md','MODEL_CARD.md')]:
        url=f'https://huggingface.co/{REPO}/resolve/{revision}/{remote}'
        print('Downloading',remote,flush=True)
        temporary=target/(local+'.part')
        with urllib.request.urlopen(url,timeout=120) as response,temporary.open('wb') as out:
            while block:=response.read(1024*1024): out.write(block)
        actual=hashlib.sha256(temporary.read_bytes()).hexdigest()
        if actual!=lock['files'][local]['sha256']:
            raise ValueError('Downloaded file does not match the pinned model hash: '+local)
        temporary.replace(target/local)
        manifest['files'][local]={'sha256':hashlib.sha256((target/local).read_bytes()).hexdigest(),'bytes':(target/local).stat().st_size,'source':url}
    (target/'manifest.json').write_text(json.dumps(manifest,indent=2),encoding='utf8')
    print('Model ready:',revision,flush=True)
if __name__=='__main__':main()
