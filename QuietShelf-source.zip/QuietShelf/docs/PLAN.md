# Build plan and completed scope

Problem: a pile of unhelpfully named text notes makes organization tedious. Product: a local review desk which proposes semantic shelves and leaves weak matches visible.

Acceptance: real open-weight inference with no runtime internet; user-selectednotes only; descriptionseditable; chunklongnotes; visiblyabstain; exact decoded-textduplicatesflagged; humanconfirm/override; exportonlyreviewed; nofilemoves; clearprivacyboundaries. Implemented with all-MiniLM-L6-v2/ONNXCPU, PythonHTTPloopback, browserreviewUI. Newsource20October2026.

Verification:10automatedtests; actualbrowserinference/review/override/export/filter; savedexport parsed. Demo and writeup prepared. No user-time benefit measured. Release contains code/modelsetup/lock/licenses, not localvenv/weights/userdata.

Deferred: PDF/OCR, free-form chat, model generation, file operations, multiuser auth, persistence, multilingual evaluation, new shelf creation in UI. These are not claimed as complete.
