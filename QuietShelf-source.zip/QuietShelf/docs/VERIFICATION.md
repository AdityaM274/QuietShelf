# Verification —20October2026

Actual model: sentence-transformers/all-MiniLM-L6-v2, revision1110a243fdf4706b3f48f1d95db1a4f5529b4d41. ONNX Runtime CPU, tokenizers, NumPy.10 tests passed. First fixture test expected unconditional assignment; that expectation was corrected after actual inference showed intended conservative abstention. No threshold was lowered to make the test pass. All five substantive fixture notes rank their intended shelf first; three still require manual choice. This is not a representative benchmark.

Browser: loaded seven fictional notes; actual model call showed240ms in that one run (not a benchmark). Confirmed d1, manually assigned ambiguous d2, changed an approved choice (review cleared), reconfirmed, exported. Downloaded JSON has2reviewed rows and5excluded. Filtered exact copies and pending review; no console errors observed. The initial download event wait timed out after the file was downloaded; the actual saved export was independently parsed to verify contents. No failed UI event is being counted as an absent download.

No user files inspected or changed. No real-user outcome or time saving measured. No offline browser network trace was captured; inference tests patch both socket.connect and create_connection to fail. Runtime implementation uses only local model paths and no download APIs. Initial package/model setup did use internet.

Limitations: reviewed plan is an export, not automatic organization. English model; no PDF/OCR, sync, account system, filesystem moves or model generation. Same names in different source folders may be ambiguous because filenames, not paths, are retained. Retain original content and verify hash/text before any manual organization.
