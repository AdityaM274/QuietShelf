import json,os
from http.server import BaseHTTPRequestHandler,ThreadingHTTPServer
from pathlib import Path
from engine import Embedder,analyze,CATEGORIES,DEMO

ROOT=Path(__file__).resolve().parent
PORT=int(os.environ.get('QUIETSHELF_PORT','4175'))
MODEL=None
class Handler(BaseHTTPRequestHandler):
    def log_message(self,*args):pass
    def reply(self,code,body,ctype='application/json'):
        data=json.dumps(body,ensure_ascii=False).encode() if ctype=='application/json' else body
        self.send_response(code);self.send_header('Content-Type',ctype);self.send_header('Content-Length',str(len(data)))
        self.send_header('Cache-Control','no-store');self.send_header('X-Content-Type-Options','nosniff')
        self.send_header('Content-Security-Policy',"default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; connect-src 'self'; object-src 'none'; frame-ancestors 'none'; base-uri 'none'")
        self.end_headers();self.wfile.write(data)
    def valid_host(self):
        return self.headers.get('Host') in {f'127.0.0.1:{PORT}',f'localhost:{PORT}'}
    def do_GET(self):
        if not self.valid_host():return self.reply(403,{'error':'Loopback host required'})
        if self.path=='/api/status':return self.reply(200,{'ready':MODEL is not None,'model':MODEL.manifest['repository'] if MODEL else None,'categories':CATEGORIES})
        if self.path=='/api/demo':return self.reply(200,{'documents':DEMO,'categories':CATEGORIES})
        files={'/':('index.html','text/html; charset=utf-8'),'/app.js':('app.js','text/javascript; charset=utf-8'),'/style.css':('style.css','text/css; charset=utf-8')}
        if self.path not in files:return self.reply(404,{'error':'Not found'})
        name,kind=files[self.path];return self.reply(200,(ROOT/'public'/name).read_bytes(),kind)
    def do_POST(self):
        if not self.valid_host():return self.reply(403,{'error':'Loopback host required'})
        origin=self.headers.get('Origin')
        if origin and origin not in {f'http://127.0.0.1:{PORT}',f'http://localhost:{PORT}'}:return self.reply(403,{'error':'Same-origin browser access only'})
        if self.path!='/api/analyze':return self.reply(404,{'error':'Not found'})
        if self.headers.get_content_type()!='application/json':return self.reply(415,{'error':'JSON required'})
        try:
            length=int(self.headers.get('Content-Length','0'))
            if length<1 or length>2000000:return self.reply(413,{'error':'Batch too large (2MB maximum)'})
            if MODEL is None:return self.reply(503,{'error':'Run setup_model.py first; no fallback results are invented'})
            result=analyze(json.loads(self.rfile.read(length)),MODEL)
            return self.reply(200,result)
        except (ValueError,UnicodeError) as e:return self.reply(400,{'error':str(e)})
        except Exception:return self.reply(500,{'error':'Inference failed. Reduce batch size and restart; no files were changed.'})
def main():
    global MODEL
    print('Loading verified local model...',flush=True);MODEL=Embedder()
    print(f'QuietShelf http://127.0.0.1:{PORT} — no remote inference',flush=True)
    ThreadingHTTPServer(('127.0.0.1',PORT),Handler).serve_forever()
if __name__=='__main__':main()
