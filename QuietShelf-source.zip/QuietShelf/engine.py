"""QuietShelf: local embeddings propose; the reader decides."""
import hashlib,json,re,time,threading
from pathlib import Path
import numpy as np

ROOT=Path(__file__).resolve().parent
CATEGORIES=[
 {'id':'study','name':'Learning','description':'University learning material, algorithms, programming notes, operating systems, computer science courses and exam revision.'},
 {'id':'career','name':'Career','description':'Internship applications, job interviews, resume feedback, recruiter messages, hiring opportunities and professional development.'},
 {'id':'life','name':'Everyday life','description':'Grocery lists, cooking recipes, household chores, laundry, meals, travel packing and personal errands.'},
 {'id':'project','name':'Building','description':'Software project requirements, bug reports, product design, deployment plans, application features and release checklists.'}
]
DEMO=[
 {'id':'d1','name':'scan_04.txt','text':'Dijkstra finds shortest paths with nonnegative edge weights. Maintain a priority queue of tentative distances. Relax outgoing edges, skip stale entries and trace the algorithm on a weighted graph before the exam.'},
 {'id':'d2','name':'untitled.md','text':'Deadlock requires mutual exclusion, hold and wait, no preemption and circular wait. Compare semaphore and mutex synchronization. Revise process scheduling and virtual memory for the operating systems examination.'},
 {'id':'d3','name':'later.txt','text':'The internship interview is on Friday. Review the job description, prepare two project examples and update the resume. Ask the recruiter about the application timeline and the next hiring round.'},
 {'id':'d4','name':'list_2.txt','text':'Buy oats, tomatoes, chickpeas and yogurt. Soak the beans overnight. Roast vegetables for dinner, pack lunch for tomorrow and finish laundry before the weekend.'},
 {'id':'d5','name':'notes.md','text':'Release checklist for the application: fix the login error, add keyboard focus styles and test the API timeout. Deploy to staging, verify the build and document the rollback procedure.'},
 {'id':'d6','name':'copy_of_scan.txt','text':'Dijkstra finds shortest paths with nonnegative edge weights. Maintain a priority queue of tentative distances. Relax outgoing edges, skip stale entries and trace the algorithm on a weighted graph before the exam.'},
 {'id':'d7','name':'fragment.txt','text':'Tuesday. Blue. Perhaps later.'}
]
def normalized(v):
    return v/np.maximum(np.linalg.norm(v,axis=-1,keepdims=True),1e-9)

class Embedder:
    def __init__(self,path=None):
        import onnxruntime as ort
        from tokenizers import Tokenizer
        path=Path(path or ROOT/'models')
        self.manifest=json.loads((path/'manifest.json').read_text('utf8'))
        for name,item in self.manifest['files'].items():
            if Path(name).name!=name:raise ValueError('Invalid model manifest')
            if hashlib.sha256((path/name).read_bytes()).hexdigest()!=item['sha256']:raise ValueError('Model integrity check failed: '+name)
        opts=ort.SessionOptions();opts.intra_op_num_threads=2;opts.inter_op_num_threads=1
        self.session=ort.InferenceSession(str(path/'model.onnx'),sess_options=opts,providers=['CPUExecutionProvider'])
        self.tokenizer=Tokenizer.from_file(str(path/'tokenizer.json'))
        self.tokenizer.no_truncation();self.tokenizer.no_padding()
        self.cls=self.tokenizer.token_to_id('[CLS]');self.sep=self.tokenizer.token_to_id('[SEP]')
        self.lock=threading.Lock()
    def encode(self,texts):
        results=[]; chunk_counts=[]
        with self.lock:
            for text in texts:
                ids=self.tokenizer.encode(text,add_special_tokens=False).ids
                parts=[ids[i:i+254] for i in range(0,len(ids),192)] or [[]]
                vecs=[]
                for part in parts:
                    tokens=np.array([[self.cls]+part+[self.sep]],dtype=np.int64)
                    mask=np.ones_like(tokens)
                    feeds={'input_ids':tokens,'attention_mask':mask,'token_type_ids':np.zeros_like(tokens)}
                    feeds={i.name:feeds[i.name] for i in self.session.get_inputs()}
                    hidden=self.session.run(None,feeds)[0]
                    vecs.append(normalized(hidden.mean(axis=1))[0])
                results.append(normalized(np.mean(vecs,axis=0)))
                chunk_counts.append(len(parts))
        return np.stack(results),chunk_counts

def validate(payload):
    if not isinstance(payload,dict):raise ValueError('Expected an object')
    docs=payload.get('documents');cats=payload.get('categories',CATEGORIES)
    if not isinstance(docs,list) or not 1<=len(docs)<=30:raise ValueError('Choose 1–30 text documents')
    if not isinstance(cats,list) or not 1<=len(cats)<=8:raise ValueError('Use 1–8 shelves')
    seen=set();clean=[];total=0
    for d in docs:
        if not isinstance(d,dict):raise ValueError('Invalid document')
        ident=d.get('id');name=d.get('name');text=d.get('text')
        if not isinstance(ident,str) or not re.fullmatch(r'[A-Za-z0-9_-]{1,60}',ident) or ident in seen:raise ValueError('Document IDs must be unique and simple')
        if not isinstance(name,str) or not name.strip() or len(name)>160 or '/' in name or '\\' in name or '\x00' in name:raise ValueError('Use a filename, not a path')
        if not isinstance(text,str) or not text.strip() or len(text)>40000:raise ValueError('Each document needs 1–40,000 text characters')
        total+=len(text)
        if total>500000:raise ValueError('Keep the batch below 500,000 text characters')
        seen.add(ident);clean.append({'id':ident,'name':name,'text':text})
    seen=set();shelves=[]
    for c in cats:
        if not isinstance(c,dict):raise ValueError('Invalid shelf')
        ident=c.get('id');name=c.get('name');desc=c.get('description')
        if not isinstance(ident,str) or not re.fullmatch(r'[A-Za-z0-9_-]{1,40}',ident) or ident in seen:raise ValueError('Shelf IDs must be unique and simple')
        if not isinstance(name,str) or not name.strip() or len(name)>60:raise ValueError('Shelf name required (60 characters maximum)')
        if not isinstance(desc,str) or not desc.strip() or len(desc)>800:raise ValueError('Describe each shelf in 1–800 characters')
        seen.add(ident);shelves.append({'id':ident,'name':name,'description':desc})
    threshold=payload.get('threshold',0.32)
    if isinstance(threshold,bool) or not isinstance(threshold,(int,float)) or not 0.1<=threshold<=0.9:raise ValueError('Similarity threshold must be 0.1–0.9')
    return clean,shelves,float(threshold)

def analyze(payload,embedder):
    docs,cats,threshold=validate(payload);start=time.perf_counter()
    vectors,chunks=embedder.encode([c['description'] for c in cats]+[d['text'] for d in docs])
    category_vectors=vectors[:len(cats)];dv=vectors[len(cats):]
    scores=dv@category_vectors.T;similarity=dv@dv.T
    hashes={};rows=[]
    for i,d in enumerate(docs):
        order=np.argsort(-scores[i],kind='stable');best=int(order[0]);top=float(scores[i,best]);second=float(scores[i,order[1]]) if len(cats)>1 else -1
        h=hashlib.sha256(d['text'].encode('utf8')).hexdigest()
        duplicate=hashes.get(h);hashes.setdefault(h,d['id'])
        reasons=[]
        if len(d['text'].split())<8:reasons.append('Too little context to classify reliably')
        if top<threshold:reasons.append('Below the similarity threshold')
        if top-second<0.04:reasons.append('The two best shelves are too close')
        suggested=None if reasons else cats[best]['id']
        near=[{'id':docs[j]['id'],'similarity':round(float(similarity[i,j]),4)} for j in range(i) if similarity[i,j]>=0.92 and docs[j]['text']!=d['text']]
        # Quote source text, never generate a purported summary.
        sentences=[s.strip() for s in re.split(r'(?<=[.!?])\s+|\n+',d['text']) if s.strip()]
        quote=max(sentences,key=lambda s:len(set(re.findall(r'\w+',s.lower())) & set(re.findall(r'\w+',cats[best]['description'].lower()))))[:280]
        rows.append({'id':d['id'],'name':d['name'],'suggested':suggested,'review':bool(reasons),'reasons':reasons,'scores':[{'shelf':cats[int(j)]['id'],'score':round(float(scores[i,j]),4)} for j in order], 'margin':round(top-second,4),'quote':quote,'sha256':h,'duplicate_of':duplicate,'similar_to':near,'chunks':chunks[len(cats)+i]})
    return {'documents':rows,'categories':cats,'threshold':threshold,'elapsed_ms':round((time.perf_counter()-start)*1000),'model':embedder.manifest['repository'],'revision':embedder.manifest['revision'],'mode':'CPU · local inference','policy':'Suggestions only. Similarity is not a probability. Source files are never changed.'}
