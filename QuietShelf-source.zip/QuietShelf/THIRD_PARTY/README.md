Model: sentence-transformers/all-MiniLM-L6-v2, Apache-2.0. See model-lock.json for immutable revision and source URLs.
ONNX Runtime: MIT, https://github.com/microsoft/onnxruntime
Hugging Face tokenizers: Apache-2.0, https://github.com/huggingface/tokenizers
NumPy: BSD-3-Clause, https://numpy.org/doc/stable/license.html
These components retain their respective licenses.
