import unittest,json,socket,sys
from pathlib import Path
from unittest.mock import patch
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from engine import Embedder,analyze,validate,DEMO,CATEGORIES

class EngineTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):cls.model=Embedder()
    def test_actual_model_offline_and_demo_labels(self):
        with patch.object(socket,'create_connection',side_effect=AssertionError('Runtime network forbidden')),patch.object(socket.socket,'connect',side_effect=AssertionError('Runtime network forbidden')):
            r=analyze({'documents':DEMO},self.model)
        rows={d['id']:d for d in r['documents']}
        self.assertEqual([rows[f'd{i}']['scores'][0]['shelf'] for i in range(1,6)],['study','study','career','life','project'])
        self.assertEqual([rows[f'd{i}']['suggested'] for i in range(1,6)],['study',None,'career',None,None])
        self.assertEqual(rows['d6']['duplicate_of'],'d1');self.assertTrue(rows['d7']['review']);self.assertIsNone(rows['d7']['suggested'])
        self.assertTrue(all(x['quote'] in next(d['text'] for d in DEMO if d['id']==x['id']) for x in rows.values()))
    def test_context_near_end_is_encoded(self):
        long=' '.join(['banana']*500)+' '+' '.join(['software deployment bug release API']*70)
        vector,counts=self.model.encode([long]);self.assertGreater(counts[0],1);self.assertEqual(vector.shape,(1,384))
    def test_strict_threshold_can_abstain(self):
        r=analyze({'documents':DEMO,'threshold':0.9},self.model)
        self.assertTrue(all(x['suggested'] is None for x in r['documents']))
    def test_custom_shelves_change_classification(self):
        cats=[{'id':'alg','name':'Algorithms','description':DEMO[0]['text']},{'id':'cook','name':'Cooking','description':DEMO[3]['text']}]
        r=analyze({'documents':[DEMO[0],DEMO[3]],'categories':cats},self.model)
        self.assertEqual([d['suggested'] for d in r['documents']],['alg','cook'])
    def test_reject_bad_inputs(self):
        for bad in [None,{}, {'documents':[]},{'documents':[DEMO[0],DEMO[0]]},{'documents':[dict(DEMO[0],name='../secret')]},{'documents':[dict(DEMO[0],text='')]},{'documents':DEMO,'threshold':True},{'documents':DEMO,'threshold':float('nan')},{'documents':DEMO,'categories':[]}]:
            with self.subTest(bad=bad),self.assertRaises(ValueError):validate(bad)
    def test_exact_hash_is_not_loose_whitespace_match(self):
        docs=[DEMO[0],dict(DEMO[0],id='second',text=DEMO[0]['text']+' ')]
        r=analyze({'documents':docs},self.model)
        self.assertIsNone(r['documents'][1]['duplicate_of']);self.assertTrue(r['documents'][1]['similar_to'])
if __name__=='__main__':unittest.main()
