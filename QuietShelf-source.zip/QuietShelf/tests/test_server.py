import unittest,threading,json,sys,http.client
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import server
from engine import Embedder,DEMO
class ServerTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        server.MODEL=Embedder();cls.http=server.ThreadingHTTPServer(('127.0.0.1',0),server.Handler);server.PORT=cls.http.server_port
        cls.thread=threading.Thread(target=cls.http.serve_forever,daemon=True);cls.thread.start()
    @classmethod
    def tearDownClass(cls):cls.http.shutdown();cls.http.server_close()
    def request(self,path,body=None,headers=None):
        conn=http.client.HTTPConnection('127.0.0.1',server.PORT,timeout=30)
        conn.request('POST' if body is not None else 'GET',path,body=json.dumps(body) if body is not None else None,headers={'Content-Type':'application/json',**(headers or {})})
        r=conn.getresponse();out=r.read();code=r.status;conn.close();return code,out
    def test_actual_analyze(self):
        code,data=self.request('/api/analyze',{'documents':DEMO});self.assertEqual(code,200);self.assertEqual(len(json.loads(data)['documents']),7)
    def test_origin_and_host_boundaries(self):
        self.assertEqual(self.request('/api/analyze',{'documents':DEMO},{'Origin':'https://example.com'})[0],403)
        self.assertEqual(self.request('/',headers={'Host':'attacker.example'})[0],403)
    def test_files_are_allowlisted(self):
        self.assertEqual(self.request('/models/manifest.json')[0],404)
        self.assertEqual(self.request('/../engine.py')[0],404)
        self.assertEqual(self.request('/engine.py')[0],404)
        self.assertEqual(self.request('/')[0],200)
    def test_bad_payload_not_fake_results(self):self.assertEqual(self.request('/api/analyze',{'documents':[]})[0],400)
if __name__=='__main__':unittest.main()
