@echo off
cd /d "%~dp0"
if not exist .venv\Scripts\python.exe (
  python -m venv .venv
  .venv\Scripts\python.exe -m pip install -r requirements-lock.txt
)
if not exist models\manifest.json .venv\Scripts\python.exe setup_model.py
echo Open http://127.0.0.1:4175/ after the model loads.
.venv\Scripts\python.exe server.py
pause
